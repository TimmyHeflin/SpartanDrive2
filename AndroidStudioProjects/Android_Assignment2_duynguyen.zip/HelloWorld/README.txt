Student name : Duy Nguyen
Student ID: 009523423
Student email: duynguyen0428@gmail.com


I added a new login activity, add to the mainfest config. 